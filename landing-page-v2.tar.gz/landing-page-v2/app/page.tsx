"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import {
  CheckCircle2,
  TrendingUp,
  Zap,
  Shield,
  BarChart3,
  Rocket,
  Star,
  ArrowRight,
  Award,
  Clock,
  DollarSign,
  Target,
  Sparkles
} from "lucide-react"
import Link from "next/link"

interface Plan {
  planId: string
  name: string
  description: string
  price: number
  originalPrice: number | null
  discountPercentage: number | null
  billingCycle: string
  durationMonths: number
  features: {
    maxAccounts: number
    maxAutomationRules: number
    maxCampaigns: number
    support: string
  }
  featuresList: string[]
  isActive: boolean
  displayOrder: number
  isPopular?: boolean
}

const APP_URL = process.env.NEXT_PUBLIC_APP_URL || 'https://app.adspilot.id'
const API_URL = process.env.NEXT_PUBLIC_API_URL || 'https://app.adspilot.id'

export default function LandingPage() {
  const [plans, setPlans] = useState<Plan[]>([])
  const [loadingPlans, setLoadingPlans] = useState(true)

  useEffect(() => {
    const fetchPlans = async () => {
      try {
        setLoadingPlans(true)
        const response = await fetch(`${API_URL}/api/plans`)
        const result = await response.json()
        if (result.success) {
          setPlans(result.data)
        }
      } catch (error) {
        console.error('Error fetching plans:', error)
      } finally {
        setLoadingPlans(false)
      }
    }
    fetchPlans()
  }, [])

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('id-ID', {
      style: 'currency',
      currency: 'IDR',
      minimumFractionDigits: 0
    }).format(price)
  }

  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <header className="sticky top-0 z-50 w-full border-b bg-white/95 backdrop-blur supports-[backdrop-filter]:bg-white/60">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex h-16 items-center justify-between">
            <div className="flex items-center gap-2">
              <Rocket className="h-8 w-8 text-primary" />
              <span className="text-xl font-bold text-foreground">ADSPILOT</span>
            </div>
            <nav className="hidden md:flex items-center gap-6">
              <Link href="#fitur" className="text-sm font-medium text-muted-foreground hover:text-foreground transition-colors">
                Fitur
              </Link>
              <Link href="#harga" className="text-sm font-medium text-muted-foreground hover:text-foreground transition-colors">
                Harga
              </Link>
              <Link href="#testimoni" className="text-sm font-medium text-muted-foreground hover:text-foreground transition-colors">
                Testimoni
              </Link>
            </nav>
            <div className="flex items-center gap-3">
              <Button variant="ghost" size="sm" asChild>
                <Link href={`${APP_URL}/auth/login`}>Masuk</Link>
              </Button>
              <Button size="sm" asChild>
                <Link href="#harga">Daftar Sekarang</Link>
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="relative overflow-hidden bg-gradient-to-br from-primary/10 via-primary/5 to-white py-20 lg:py-32">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 max-w-7xl">
          <div className="flex flex-col items-center text-center max-w-4xl mx-auto">
            <div className="inline-flex items-center gap-2 bg-primary/10 text-primary px-4 py-2 rounded-full text-sm font-semibold mb-6">
              <Sparkles className="h-4 w-4" />
              Otomasi Iklan Shopee 24/7
            </div>

            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold text-foreground mb-6 leading-tight">
              Tingkatkan Penjualan Shopee Anda{" "}
              <span className="text-primary">Hingga 300%</span>{" "}
              dengan Otomasi Cerdas!
            </h1>

            <p className="text-lg lg:text-xl text-muted-foreground mb-8 max-w-2xl">
              Hentikan ketakutan budget iklan habis sia-sia. ADSPILOT mengelola iklan Shopee Anda
              secara otomatis 24/7, <strong>tanpa perlu bangun tengah malam</strong> untuk setting iklan.
            </p>

            <div className="flex flex-col sm:flex-row gap-4 mb-12">
              <Button size="lg" className="text-base px-8" asChild>
                <Link href="#harga">
                  Mulai Gratis
                  <ArrowRight className="ml-2 h-5 w-5" />
                </Link>
              </Button>
              <Button size="lg" variant="outline" className="text-base px-8" asChild>
                <Link href="#fitur">Lihat Fitur</Link>
              </Button>
            </div>

            <div className="flex items-center gap-6 flex-wrap justify-center text-sm text-muted-foreground">
              <div className="flex items-center gap-2">
                <Clock className="h-4 w-4 text-primary" />
                <span>Otomasi 24/7</span>
              </div>
              <div className="flex items-center gap-2">
                <Shield className="h-4 w-4 text-primary" />
                <span>Aman & Terpercaya</span>
              </div>
              <div className="flex items-center gap-2">
                <Zap className="h-4 w-4 text-primary" />
                <span>Setup 5 Menit</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section id="fitur" className="py-20 bg-white">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 max-w-7xl">
          <div className="mx-auto max-w-3xl text-center mb-16">
            <h2 className="text-3xl sm:text-4xl font-bold text-foreground mb-4">
              Semua yang Anda Butuhkan untuk{" "}
              <span className="text-primary">Sukses di Shopee</span>
            </h2>
            <p className="text-lg text-muted-foreground">
              Fitur lengkap yang dirancang khusus untuk membantu seller Shopee meningkatkan penjualan
            </p>
          </div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-8">
            {/* Feature 1 */}
            <Card className="p-6 border-2 hover:border-primary/50 transition-colors">
              <div className="flex items-center gap-3 mb-4">
                <div className="h-12 w-12 rounded-lg bg-primary/10 flex items-center justify-center">
                  <Zap className="h-6 w-6 text-primary" />
                </div>
                <h3 className="text-xl font-bold text-foreground">Otomasi Iklan Cerdas</h3>
              </div>
              <p className="text-muted-foreground mb-4">
                Atur iklan Anda sekali, biarkan AdsPilot yang mengelola. Sistem otomasi kami akan
                mengoptimalkan budget dan bid secara otomatis untuk hasil maksimal.
              </p>
              <ul className="space-y-2">
                <li className="flex items-start gap-2 text-sm">
                  <CheckCircle2 className="h-4 w-4 text-primary mt-0.5 shrink-0" />
                  <span>Auto-bid berdasarkan performa</span>
                </li>
                <li className="flex items-start gap-2 text-sm">
                  <CheckCircle2 className="h-4 w-4 text-primary mt-0.5 shrink-0" />
                  <span>Jadwal iklan otomatis</span>
                </li>
                <li className="flex items-start gap-2 text-sm">
                  <CheckCircle2 className="h-4 w-4 text-primary mt-0.5 shrink-0" />
                  <span>Pause iklan yang tidak efektif</span>
                </li>
              </ul>
            </Card>

            {/* Feature 2 */}
            <Card className="p-6 border-2 hover:border-primary/50 transition-colors">
              <div className="flex items-center gap-3 mb-4">
                <div className="h-12 w-12 rounded-lg bg-primary/10 flex items-center justify-center">
                  <BarChart3 className="h-6 w-6 text-primary" />
                </div>
                <h3 className="text-xl font-bold text-foreground">Analitik Real-Time</h3>
              </div>
              <p className="text-muted-foreground mb-4">
                Pantau performa iklan Anda secara real-time. Lihat ROI, conversion rate,
                dan metrik penting lainnya dalam satu dashboard yang mudah dipahami.
              </p>
              <ul className="space-y-2">
                <li className="flex items-start gap-2 text-sm">
                  <CheckCircle2 className="h-4 w-4 text-primary mt-0.5 shrink-0" />
                  <span>Dashboard interaktif</span>
                </li>
                <li className="flex items-start gap-2 text-sm">
                  <CheckCircle2 className="h-4 w-4 text-primary mt-0.5 shrink-0" />
                  <span>Analisa data harian otomatis</span>
                </li>
                <li className="flex items-start gap-2 text-sm">
                  <CheckCircle2 className="h-4 w-4 text-primary mt-0.5 shrink-0" />
                  <span>Prediksi performa</span>
                </li>
              </ul>
            </Card>

            {/* Feature 3 */}
            <Card className="p-6 border-2 hover:border-primary/50 transition-colors">
              <div className="flex items-center gap-3 mb-4">
                <div className="h-12 w-12 rounded-lg bg-primary/10 flex items-center justify-center">
                  <Target className="h-6 w-6 text-primary" />
                </div>
                <h3 className="text-xl font-bold text-foreground">Rekam Medic - BCG Matrix</h3>
              </div>
              <p className="text-muted-foreground mb-4">
                Diagnosis kesehatan iklan dengan teknologi BCG Matrix dari Fortune 500. Ketahui iklan mana yang produktif dan mana yang buang-buang budget.
              </p>
              <ul className="space-y-2">
                <li className="flex items-start gap-2 text-sm">
                  <CheckCircle2 className="h-4 w-4 text-primary mt-0.5 shrink-0" />
                  <span>Kategorisasi iklan otomatis</span>
                </li>
                <li className="flex items-start gap-2 text-sm">
                  <CheckCircle2 className="h-4 w-4 text-primary mt-0.5 shrink-0" />
                  <span>Analisis Star, Cash Cow, Dog</span>
                </li>
                <li className="flex items-start gap-2 text-sm">
                  <CheckCircle2 className="h-4 w-4 text-primary mt-0.5 shrink-0" />
                  <span>Rekomendasi aksi cerdas</span>
                </li>
              </ul>
            </Card>

            {/* Feature 4 */}
            <Card className="p-6 border-2 hover:border-primary/50 transition-colors">
              <div className="flex items-center gap-3 mb-4">
                <div className="h-12 w-12 rounded-lg bg-primary/10 flex items-center justify-center">
                  <DollarSign className="h-6 w-6 text-primary" />
                </div>
                <h3 className="text-xl font-bold text-foreground">Hemat Budget Hingga 40%</h3>
              </div>
              <p className="text-muted-foreground mb-4">
                Optimalkan pengeluaran iklan Anda tanpa mengurangi performa. Sistem kami
                memastikan setiap rupiah yang Anda keluarkan memberikan hasil maksimal.
              </p>
              <ul className="space-y-2">
                <li className="flex items-start gap-2 text-sm">
                  <CheckCircle2 className="h-4 w-4 text-primary mt-0.5 shrink-0" />
                  <span>Smart budget allocation</span>
                </li>
                <li className="flex items-start gap-2 text-sm">
                  <CheckCircle2 className="h-4 w-4 text-primary mt-0.5 shrink-0" />
                  <span>Deteksi iklan tidak efektif</span>
                </li>
                <li className="flex items-start gap-2 text-sm">
                  <CheckCircle2 className="h-4 w-4 text-primary mt-0.5 shrink-0" />
                  <span>Rekomendasi optimasi budget</span>
                </li>
              </ul>
            </Card>

            {/* Feature 5 */}
            <Card className="p-6 border-2 hover:border-primary/50 transition-colors">
              <div className="flex items-center gap-3 mb-4">
                <div className="h-12 w-12 rounded-lg bg-primary/10 flex items-center justify-center">
                  <Shield className="h-6 w-6 text-primary" />
                </div>
                <h3 className="text-xl font-bold text-foreground">100% Aman & Terpercaya</h3>
              </div>
              <p className="text-muted-foreground mb-4">
                Data dan akun Shopee Anda aman bersama kami. Kami menggunakan enkripsi
                tingkat enterprise dan tidak pernah menyimpan password Anda.
              </p>
              <ul className="space-y-2">
                <li className="flex items-start gap-2 text-sm">
                  <CheckCircle2 className="h-4 w-4 text-primary mt-0.5 shrink-0" />
                  <span>Enkripsi SSL 256-bit</span>
                </li>
                <li className="flex items-start gap-2 text-sm">
                  <CheckCircle2 className="h-4 w-4 text-primary mt-0.5 shrink-0" />
                  <span>Session cookies terenkripsi</span>
                </li>
                <li className="flex items-start gap-2 text-sm">
                  <CheckCircle2 className="h-4 w-4 text-primary mt-0.5 shrink-0" />
                  <span>Disconnect kapan saja</span>
                </li>
              </ul>
            </Card>

            {/* Feature 6 */}
            <Card className="p-6 border-2 hover:border-primary/50 transition-colors">
              <div className="flex items-center gap-3 mb-4">
                <div className="h-12 w-12 rounded-lg bg-primary/10 flex items-center justify-center">
                  <Rocket className="h-6 w-6 text-primary" />
                </div>
                <h3 className="text-xl font-bold text-foreground">Setup dalam 5 Menit</h3>
              </div>
              <p className="text-muted-foreground mb-4">
                Tidak perlu ribet! Setup AdsPilot hanya butuh 5 menit. Koneksikan akun Shopee
                Anda, pilih produk yang ingin diiklankan, dan biarkan AdsPilot bekerja.
              </p>
              <ul className="space-y-2">
                <li className="flex items-start gap-2 text-sm">
                  <CheckCircle2 className="h-4 w-4 text-primary mt-0.5 shrink-0" />
                  <span>Koneksi akun Shopee mudah</span>
                </li>
                <li className="flex items-start gap-2 text-sm">
                  <CheckCircle2 className="h-4 w-4 text-primary mt-0.5 shrink-0" />
                  <span>Buat automation rules cepat</span>
                </li>
                <li className="flex items-start gap-2 text-sm">
                  <CheckCircle2 className="h-4 w-4 text-primary mt-0.5 shrink-0" />
                  <span>Support via Telegram</span>
                </li>
              </ul>
            </Card>
          </div>
        </div>
      </section>

      {/* Pricing Section */}
      <section id="harga" className="py-20 bg-gradient-to-br from-primary/5 to-white">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 max-w-7xl">
          <div className="mx-auto max-w-3xl text-center mb-16">
            <h2 className="text-3xl sm:text-4xl font-bold text-foreground mb-4">
              Pilih Paket yang{" "}
              <span className="text-primary">Sesuai untuk Anda</span>
            </h2>
            <p className="text-lg text-muted-foreground">
              Investasi terbaik untuk mengembangkan bisnis Shopee Anda
            </p>
          </div>

          {loadingPlans ? (
            <div className="text-center py-12">
              <div className="inline-block h-8 w-8 animate-spin rounded-full border-4 border-solid border-primary border-r-transparent"></div>
              <p className="mt-4 text-muted-foreground">Memuat paket...</p>
            </div>
          ) : (
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 max-w-6xl mx-auto">
              {plans.map((plan) => (
                <Card
                  key={plan.planId}
                  className={`p-8 relative ${plan.isPopular
                      ? 'border-2 border-primary shadow-lg scale-105'
                      : 'border-2 hover:border-primary/50'
                    } transition-all`}
                >
                  {plan.isPopular && (
                    <div className="absolute -top-4 left-1/2 -translate-x-1/2">
                      <div className="bg-primary text-primary-foreground px-4 py-1 rounded-full text-sm font-semibold">
                        Paling Populer
                      </div>
                    </div>
                  )}

                  <div className="text-center mb-6">
                    <h3 className="text-2xl font-bold text-foreground mb-2">{plan.name}</h3>
                    <p className="text-sm text-muted-foreground mb-4">{plan.description}</p>

                    <div className="mb-4">
                      {plan.originalPrice && plan.originalPrice > plan.price && (
                        <div className="text-sm text-muted-foreground line-through">
                          {formatPrice(plan.originalPrice)}
                        </div>
                      )}
                      <div className="text-4xl font-bold text-foreground">
                        {formatPrice(plan.price)}
                      </div>
                      <div className="text-sm text-muted-foreground">
                        / {plan.durationMonths} bulan
                      </div>
                    </div>

                    {plan.discountPercentage && (
                      <div className="inline-block bg-green-100 text-green-700 px-3 py-1 rounded-full text-sm font-semibold">
                        Hemat {plan.discountPercentage}%
                      </div>
                    )}
                  </div>

                  <ul className="space-y-3 mb-8">
                    {plan.featuresList.map((feature, idx) => (
                      <li key={idx} className="flex items-start gap-2 text-sm">
                        <CheckCircle2 className="h-5 w-5 text-primary mt-0.5 shrink-0" />
                        <span>{feature}</span>
                      </li>
                    ))}
                  </ul>

                  <Button
                    className="w-full"
                    variant={plan.isPopular ? 'default' : 'outline'}
                    size="lg"
                    asChild
                  >
                    <Link href={`${APP_URL}/auth/register?plan=${plan.planId}`}>
                      Pilih Paket Ini
                    </Link>
                  </Button>
                </Card>
              ))}
            </div>
          )}
        </div>
      </section>

      {/* Testimonials Section */}
      <section id="testimoni" className="py-20 bg-white">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 max-w-7xl">
          <div className="mx-auto max-w-3xl text-center mb-16">
            <h2 className="text-3xl sm:text-4xl font-bold text-foreground mb-4">
              Apa Kata Mereka yang Sudah{" "}
              <span className="text-primary">Menggunakan ADSPILOT</span>
            </h2>
            <p className="text-lg text-muted-foreground">
              Seller yang sudah merasakan manfaat otomasi iklan dengan ADSPILOT
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {[
              {
                name: "Budi Santoso",
                role: "Owner Toko Fashion",
                image: "BS",
                rating: 5,
                text: "Sejak pakai AdsPilot, penjualan saya meningkat signifikan! Budget iklan lebih efisien dan ROI meningkat. Sekarang saya bisa tidur nyenyak tanpa khawatir iklan boncos. Recommended!",
              },
              {
                name: "Siti Nurhaliza",
                role: "Seller Kecantikan",
                image: "SN",
                rating: 5,
                text: "Wah, enak banget! Dulu saya harus cek iklan manual setiap hari. Sekarang semua otomatis, saya bisa fokus ke produk baru. Penjualan jadi lebih stabil dan terkontrol!",
              },
              {
                name: "Ahmad Rizki",
                role: "Seller Elektronik",
                image: "AR",
                rating: 5,
                text: "ROI iklan saya meningkat setelah pakai AdsPilot. Sistem auto-bid-nya benar-benar membantu. Tidak perlu lagi bangun tengah malam untuk setting iklan. Worth it!",
              },
            ].map((testimonial, idx) => (
              <Card key={idx} className="p-6">
                <div className="flex items-center gap-1 mb-4">
                  {[...Array(testimonial.rating)].map((_, i) => (
                    <Star key={i} className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                  ))}
                </div>
                <p className="text-muted-foreground mb-6 italic">
                  "{testimonial.text}"
                </p>
                <div className="flex items-center gap-3">
                  <div className="h-12 w-12 rounded-full bg-primary/10 flex items-center justify-center text-primary font-bold">
                    {testimonial.image}
                  </div>
                  <div>
                    <p className="font-semibold text-foreground">{testimonial.name}</p>
                    <p className="text-sm text-muted-foreground">{testimonial.role}</p>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-br from-primary to-primary/80">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 max-w-4xl text-center">
          <Award className="h-16 w-16 text-white mx-auto mb-6" />
          <h2 className="text-3xl sm:text-4xl font-bold text-white mb-6">
            Siap Meningkatkan Penjualan Shopee Anda?
          </h2>
          <p className="text-lg text-white/90 mb-8">
            Bergabunglah dengan ribuan seller yang sudah merasakan manfaat otomasi iklan dengan ADSPILOT
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" variant="secondary" className="text-base px-8" asChild>
              <Link href="#harga">
                Mulai Sekarang
                <ArrowRight className="ml-2 h-5 w-5" />
              </Link>
            </Button>
            <Button size="lg" variant="outline" className="text-base px-8 bg-white hover:bg-white/90" asChild>
              <Link href={`${APP_URL}/auth/login`}>Masuk ke Dashboard</Link>
            </Button>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-50 border-t py-12">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-4 gap-8 mb-8">
            <div>
              <div className="flex items-center gap-2 mb-4">
                <Rocket className="h-6 w-6 text-primary" />
                <span className="text-lg font-bold">ADSPILOT</span>
              </div>
              <p className="text-sm text-muted-foreground">
                Otomasi iklan Shopee yang cerdas dan terpercaya untuk meningkatkan penjualan Anda.
              </p>
            </div>

            <div>
              <h3 className="font-semibold mb-4">Produk</h3>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li><Link href="#fitur" className="hover:text-foreground">Fitur</Link></li>
                <li><Link href="#harga" className="hover:text-foreground">Harga</Link></li>
                <li><Link href={`${APP_URL}`} className="hover:text-foreground">Dashboard</Link></li>
              </ul>
            </div>

            <div>
              <h3 className="font-semibold mb-4">Perusahaan</h3>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li><Link href="#testimoni" className="hover:text-foreground">Testimoni</Link></li>
                <li><Link href="#" className="hover:text-foreground">Tentang Kami</Link></li>
                <li><Link href="#" className="hover:text-foreground">Kontak</Link></li>
              </ul>
            </div>

            <div>
              <h3 className="font-semibold mb-4">Legal</h3>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li><Link href="#" className="hover:text-foreground">Privacy Policy</Link></li>
                <li><Link href="#" className="hover:text-foreground">Terms of Service</Link></li>
              </ul>
            </div>
          </div>

          <div className="border-t pt-8 text-center text-sm text-muted-foreground">
            <p>© 2026 ADSPILOT. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}
